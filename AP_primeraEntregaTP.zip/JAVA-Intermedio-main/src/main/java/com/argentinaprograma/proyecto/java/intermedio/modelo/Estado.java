package com.argentinaprograma.proyecto.java.intermedio.modelo;

public enum Estado {
    PENDIENTE,
    CURSO,
    RESUELTO;
	
}
