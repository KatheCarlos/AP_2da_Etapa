package com.argentinaprograma.proyecto.java.intermedio.modelo;

public enum tipoProblema {
    PROBLEMA1,
    PROBLEMA2,
    PROBLEMA3,
    PROBLEMA4,
    PROBLEMA5
}
